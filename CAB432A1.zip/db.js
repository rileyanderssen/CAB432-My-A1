// make shift database

const MockUserDB = [
    { id: 1, email: "testuser@gmail.com", password: "password" },
    { id: 2, email: "hello@gmail.com", password: "hello" },
    { id: 3, email: "otheruser@gmail.com", password: "otherpassword" },
]

const MockFileDB = [];

const MockTranscodeDB = [];

const MockFolderDB = [];

module.exports = {
    MockUserDB,
    MockFileDB,
    MockTranscodeDB,
    MockFolderDB
}